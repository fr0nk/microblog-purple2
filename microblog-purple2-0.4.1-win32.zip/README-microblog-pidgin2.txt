# win32 binaries for microblog-pidgin2

For easy installation just extract this archive into your
Pidgin installation folder (typically `C:\Program Files\Pidgin`)

- libjson-glib-1.0-0.dll goes into Pidgin folger (`C:\Program Files\Pidgin`)
- The DLL files in plugins folder go into Pidgins plugin folder (`C:\Program Files\Pidgin\plugins`)
